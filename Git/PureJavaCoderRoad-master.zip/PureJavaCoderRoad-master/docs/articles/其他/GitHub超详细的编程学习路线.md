github地址：https://github.com/kamranahmedse/developer-roadmap/tree/master/translations/chinese

总体路线：
![](https://img-blog.csdnimg.cn/img_convert/8830e9d1239fe053e75d4cbf204f9955.png)
