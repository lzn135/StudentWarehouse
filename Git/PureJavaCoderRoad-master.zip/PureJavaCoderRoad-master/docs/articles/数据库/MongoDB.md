我们此前接触的MySQL、Oracle 都是 关系型数据库（Relational Database）

NoSQL，指的是非关系型的数据库。NoSQL有时也称作Not Only SQL的缩写，是对不同于传统的关系型数据库的数据库管理系统的统称。

比如 MongoDB、Redis。

