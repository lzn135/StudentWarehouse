Java的变量可以定义不同的数据，但是Java作为一门逻辑的语言，少不了逻辑结构。

> Java的执行是从main方法开始的，但是进入了main方法之后，Java是自上而下执行的。

Java就像流程图一样，用户可以自定义逻辑判断、循环、返回、结束等等，Java也有这些流程语句。

Java的程序控制语句关键字有：

![](https://blog-1253198264.cos.ap-guangzhou.myqcloud.com/image-20210108111838227.png)


