 <div align="center"> <img src="https://blog-1253198264.cos.ap-guangzhou.myqcloud.com/%E5%85%AC%E4%BC%97%E5%8F%B7HelloCoder.png"/  style="zoom:50%;"> </div>

# 《Java小白之路》

> Java小白学到什么程度才能找到一份工作?

### 《Java小白之路》 是一个帮助Java**初学者**从入门到找到一份工作所需技能的教程文档，用极其简单的文字，让你快速掌握核心知识
- JavaSE
- 数据结构
- 计算机网络
- 操作系统
- MySQL
- JavaEE 
- Maven
- Git
- Linux
- 服务器基础
- 设计模式
- 常见架构
- 常见面试题 
- ......

<span id="busuanzi_container_site_pv">
👀    本站总访问量 <span id="busuanzi_value_site_pv"></span>次
</span>| 🐒本站访客数<span id="busuanzi_value_site_uv"></span>人次

[开始阅读](/README.md)

